// ======================================================
// main.js
// Fully runnable WebGPU cloud engine
// ======================================================

const canvas = document.getElementById("gfx");
const adapter = await navigator.gpu.requestAdapter();
const device = await adapter.requestDevice();
const context = canvas.getContext("webgpu");

const format = navigator.gpu.getPreferredCanvasFormat();
context.configure({
    device: device,
    format: format,
    alphaMode: "premultiplied"
});

// -----------------------------
// CAMERA / FLIGHT CONTROLS
// -----------------------------
let camPos = [0,10,0];
let camRot = [0,0]; // pitch, yaw
const keys = {};

window.addEventListener("keydown", e => keys[e.key.toLowerCase()] = true);
window.addEventListener("keyup", e => keys[e.key.toLowerCase()] = false);

window.addEventListener("mousemove", e => {
    if(e.buttons === 1) {
        camRot[1] -= e.movementX * 0.002;
        camRot[0] -= e.movementY * 0.002;
        camRot[0] = Math.max(-Math.PI/2, Math.min(Math.PI/2, camRot[0]));
    }
});

function getCameraFront() {
    return [
        Math.cos(camRot[1]) * Math.cos(camRot[0]),
        Math.sin(camRot[0]),
        Math.sin(camRot[1]) * Math.cos(camRot[0])
    ];
}

function updateCamera(dt) {
    const speed = 10.0;
    const front = getCameraFront();

    const right = [
        Math.sin(camRot[1] - Math.PI/2),
        0,
        Math.cos(camRot[1] - Math.PI/2)
    ];

    if(keys["w"]) camPos = camPos.map((v,i)=>v+front[i]*speed*dt);
    if(keys["s"]) camPos = camPos.map((v,i)=>v-front[i]*speed*dt);
    if(keys["a"]) camPos = camPos.map((v,i)=>v-right[i]*speed*dt);
    if(keys["d"]) camPos = camPos.map((v,i)=>v+right[i]*speed*dt);
    if(keys[" "]) camPos[1] += speed*dt;
    if(keys["shift"]) camPos[1] -= speed*dt;

    return front;
}

// -----------------------------
// UNIFORM BUFFER
// -----------------------------
const uniformBufferSize = 16 * 4; // 16 floats
const uniformBuffer = device.createBuffer({
    size: uniformBufferSize,
    usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST
});

const uniformBindGroupLayout = device.createBindGroupLayout({
    entries: [{binding:0, visibility: GPUShaderStage.FRAGMENT, buffer:{type:"uniform"}}]
});

const uniformBindGroup = device.createBindGroup({
    layout: uniformBindGroupLayout,
    entries: [{binding:0, resource:{buffer: uniformBuffer}}]
});

// -----------------------------
// FULL SCREEN TRIANGLE PIPELINE
// -----------------------------
const shaderCode = await fetch("clouds.wgsl").then(r=>r.text());

const pipeline = device.createRenderPipeline({
    layout: device.createPipelineLayout({bindGroupLayouts:[uniformBindGroupLayout]}),
    vertex: {
        module: device.createShaderModule({code: `
        @vertex
        fn vs_main(@builtin(vertex_index) VertexIndex: u32) -> @builtin(position) vec4<f32> {
            var pos = array<vec2<f32>, 3>(
                vec2<f32>(-1.0, -1.0),
                vec2<f32>(3.0, -1.0),
                vec2<f32>(-1.0, 3.0)
            );
            return vec4<f32>(pos[VertexIndex], 0.0, 1.0);
        }`
        }),
        entryPoint: "vs_main"
    },
    fragment: {
        module: device.createShaderModule({code: shaderCode}),
        entryPoint: "fs_main",
        targets: [{format: format}]
    },
    primitive: {topology:"triangle-list"}
});

// -----------------------------
// RENDER LOOP
// -----------------------------
let lastTime = 0;

function frame(time) {
    const dt = (time - lastTime)*0.001;
    lastTime = time;

    const front = updateCamera(dt);

    // Update uniforms
    const uniformData = new Float32Array(16);
    uniformData.set(camPos,0);
    uniformData.set(front,4);
    uniformData.set([0.3,0.5,0.8],8); // sunDir
    uniformData.set([time*0.001,0],12);
    device.queue.writeBuffer(uniformBuffer,0,uniformData.buffer);

    // Begin render pass
    const commandEncoder = device.createCommandEncoder();
    const textureView = context.getCurrentTexture().createView();
    const renderPass = commandEncoder.beginRenderPass({
        colorAttachments:[{
            view: textureView,
            loadOp:"clear",
            storeOp:"store",
            clearValue:{r:0,g:0,b:0,a:1}
        }]
    });

    renderPass.setPipeline(pipeline);
    renderPass.setBindGroup(0, uniformBindGroup);
    renderPass.draw(3,1,0,0);
    renderPass.end();

    device.queue.submit([commandEncoder.finish()]);
    requestAnimationFrame(frame);
}

requestAnimationFrame(frame);